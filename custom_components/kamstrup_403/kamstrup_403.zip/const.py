"""Constants for Kamstrup 403."""

from typing import Final

DOMAIN: Final = "kamstrup_403"
MANUFACTURER: Final = "Kamstrup"
MODEL: Final = "403"

DEFAULT_BAUDRATE: Final = 1200
DEFAULT_SCAN_INTERVAL: Final = 3600
DEFAULT_TIMEOUT: Final = 1.0

# Protocol limit for registers per request
MULTIPLE_REGISTERS_MAX: Final = 8

# KMP Protocol constants
ESCAPES: Final = frozenset({0x06, 0x0D, 0x1B, 0x40, 0x80})

UNITS: Final = {
    0: "",
    1: "Wh",
    2: "kWh",
    3: "MWh",
    4: "GWh",
    5: "J",
    6: "kj",
    7: "MJ",
    8: "GJ",
    9: "Cal",
    10: "kCal",
    11: "Mcal",
    12: "Gcal",
    13: "varh",
    14: "kvarh",
    15: "Mvarh",
    16: "Gvarh",
    17: "VAh",
    18: "kVAh",
    19: "MVAh",
    20: "GVAh",
    21: "kW",
    22: "kW",
    23: "MW",
    24: "GW",
    25: "kvar",
    26: "kvar",
    27: "Mvar",
    28: "Gvar",
    29: "VA",
    30: "kVA",
    31: "MVA",
    32: "GVA",
    33: "V",
    34: "A",
    35: "kV",
    36: "kA",
    37: "°C",
    38: "K",
    39: "l",
    40: "m³",
    41: "l/h",
    42: "m³/h",
    43: "m³xC",
    44: "ton",
    45: "ton/h",
    46: "h",
    47: "hh:mm:ss",
    48: "yy:mm:dd",
    49: "yyyy:mm:dd",
    50: "mm:dd",
    51: "",
    52: "bar",
    53: "RTC",
    54: "ASCII",
    55: "m³ x 10",
    56: "ton x 10",
    57: "GJ x 10",
    58: "minutes",
    59: "Bitfield",
    60: "s",
    61: "ms",
    62: "days",
    63: "RTC-Q",
    64: "Datetime",
}
